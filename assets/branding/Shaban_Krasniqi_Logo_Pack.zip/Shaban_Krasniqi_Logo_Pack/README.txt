Shaban Krasniqi Physiotherapy – Logo Pack

Includes:
- Full logo on white background
- Full logo on black background
- Icon-only logo on white background
- Icon-only logo on black background

Folders:
- PNG: original high-resolution images
- SVG: identical SVG containers embedding the corresponding PNG artwork

Note: The SVG files preserve the appearance exactly, but are not manually redrawn as editable vector paths.
